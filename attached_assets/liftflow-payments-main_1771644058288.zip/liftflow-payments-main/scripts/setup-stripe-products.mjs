/**
 * Setup Stripe Products and Prices for LiftFlow Payments
 * Run this script once to create products in Stripe test mode
 * 
 * Usage: node scripts/setup-stripe-products.mjs
 */

import Stripe from 'stripe';
// Product configuration inline to avoid TypeScript import issues
const STRIPE_PRODUCTS = [
  {
    tier: 'per_user',
    productName: 'LiftFlow Pay Per User',
    productDescription: 'Flexible per-user pricing that scales with your coaching business',
    prices: {
      monthly: {
        unitAmount: 250, // $2.50 in cents
        recurring: { interval: 'month' },
      },
      annual: {
        unitAmount: 2500, // $25 in cents
        recurring: { interval: 'year' },
      },
    },
  },
  {
    tier: 'enterprise',
    productName: 'LiftFlow Enterprise',
    productDescription: 'Unlimited users for growing teams (25+)',
    prices: {
      annual: {
        unitAmount: 50000, // $500 in cents
        recurring: { interval: 'year' },
      },
    },
  },
];

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2026-01-28.clover',
});

async function setupProducts() {
  console.log('Setting up Stripe products and prices...\n');

  for (const config of STRIPE_PRODUCTS) {
    console.log(`Creating product: ${config.productName}`);
    
    try {
      // Create product
      const product = await stripe.products.create({
        name: config.productName,
        description: config.productDescription,
        metadata: {
          tier: config.tier,
        },
      });

      console.log(`✓ Product created: ${product.id}`);

      // Create prices
      if (config.prices.monthly) {
        const monthlyPrice = await stripe.prices.create({
          product: product.id,
          unit_amount: config.prices.monthly.unitAmount,
          currency: 'usd',
          recurring: config.prices.monthly.recurring,
          metadata: {
            tier: config.tier,
            billing_cycle: 'monthly',
          },
        });
        console.log(`  ✓ Monthly price created: ${monthlyPrice.id} ($${config.prices.monthly.unitAmount / 100}/month)`);
      }

      if (config.prices.annual) {
        const annualPrice = await stripe.prices.create({
          product: product.id,
          unit_amount: config.prices.annual.unitAmount,
          currency: 'usd',
          recurring: config.prices.annual.recurring,
          metadata: {
            tier: config.tier,
            billing_cycle: 'annual',
          },
        });
        console.log(`  ✓ Annual price created: ${annualPrice.id} ($${config.prices.annual.unitAmount / 100}/year)`);
      }

      console.log('');
    } catch (error) {
      console.error(`✗ Error creating product ${config.productName}:`, error.message);
      console.log('');
    }
  }

  console.log('Done! Products and prices have been created in Stripe.');
  console.log('\nNext steps:');
  console.log('1. Go to https://dashboard.stripe.com/test/products');
  console.log('2. Copy the Price IDs for each tier and billing cycle');
  console.log('3. Update server/routers/billing.ts with the Price IDs');
}

setupProducts().catch(console.error);
