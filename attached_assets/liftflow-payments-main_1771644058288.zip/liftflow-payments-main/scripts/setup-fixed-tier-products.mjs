import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2026-01-28.clover",
});

async function setupFixedTierProducts() {
  console.log("Setting up LiftFlow fixed tier products and prices...\n");

  const tiers = [
    {
      name: "LiftFlow Starter (5 users)",
      description: "Perfect for small coaching practices - 5 clients included",
      price: 10000, // $100 in cents
      users: 5,
      key: "tier_5",
    },
    {
      name: "LiftFlow Growth (10 users)",
      description: "Scale your coaching business - 10 clients included",
      price: 17500, // $175 in cents
      users: 10,
      key: "tier_10",
    },
    {
      name: "LiftFlow Professional (25 users)",
      description: "For established coaches - 25 clients included",
      price: 37500, // $375 in cents
      users: 25,
      key: "tier_25",
    },
    {
      name: "LiftFlow Enterprise",
      description: "Unlimited users for growing teams (25+)",
      price: 50000, // $500 in cents
      users: 999,
      key: "enterprise",
    },
  ];

  const priceIds = {};

  for (const tier of tiers) {
    console.log(`Creating product: ${tier.name}...`);
    
    const product = await stripe.products.create({
      name: tier.name,
      description: tier.description,
      metadata: {
        tier: tier.key,
        userCount: tier.users.toString(),
      },
    });

    console.log(`✓ Product created: ${product.id}`);

    console.log(`Creating annual price for ${tier.name}...`);
    
    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: tier.price,
      currency: "usd",
      recurring: {
        interval: "year",
      },
      metadata: {
        tier: tier.key,
        userCount: tier.users.toString(),
      },
    });

    console.log(`✓ Annual price created: ${price.id}\n`);
    
    priceIds[tier.key] = price.id;
  }

  console.log("\n=== Stripe Price IDs ===");
  console.log("Update these in shared/products.ts:\n");
  console.log("export const STRIPE_PRICE_IDS = {");
  for (const [key, priceId] of Object.entries(priceIds)) {
    console.log(`  ${key}: "${priceId}",`);
  }
  console.log("};");
  
  console.log("\n✓ All products and prices created successfully!");
}

setupFixedTierProducts().catch((error) => {
  console.error("Error setting up products:", error);
  process.exit(1);
});
