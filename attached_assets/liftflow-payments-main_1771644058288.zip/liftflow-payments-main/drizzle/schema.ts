import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Subscriptions table - tracks active subscriptions for LiftFlow coaches
 */
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  /** Email or identifier of the coach from LiftFlow */
  coachEmail: varchar("coachEmail", { length: 320 }).notNull(),
  /** Stripe customer ID */
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  /** Stripe subscription ID */
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  /** Subscription tier */
  tier: varchar("tier", { length: 50 }).notNull(),
  /** Billing cycle */
  billingCycle: varchar("billingCycle", { length: 20 }).default("annual"),
  /** Number of users for per_user tier */
  userCount: int("userCount").default(1),
  /** Subscription status */
  status: varchar("status", { length: 20 }).default("active").notNull(),
  /** Current period start */
  currentPeriodStart: timestamp("currentPeriodStart"),
  /** Current period end */
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  /** When the subscription will be canceled (at period end) */
  cancelAt: timestamp("cancelAt"),
  /** When the subscription was canceled */
  canceledAt: timestamp("canceledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  emailIdx: index("coach_email_idx").on(table.coachEmail),
  stripeCustomerIdx: index("stripe_customer_idx").on(table.stripeCustomerId),
  stripeSubscriptionIdx: index("stripe_subscription_idx").on(table.stripeSubscriptionId),
}));

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Payments table - tracks all payment transactions
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  /** Reference to subscription */
  subscriptionId: int("subscriptionId"),
  /** Email or identifier of the coach */
  coachEmail: varchar("coachEmail", { length: 320 }).notNull(),
  /** LiftFlow user ID */
  userId: varchar("userId", { length: 255 }),
  /** Stripe payment intent ID */
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  /** Stripe checkout session ID */
  stripeCheckoutSessionId: varchar("stripeCheckoutSessionId", { length: 255 }),
  /** Payment amount in cents */
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  /** Currency code (USD) */
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  /** Payment status */
  status: mysqlEnum("status", ["pending", "succeeded", "failed", "refunded"]).default("pending").notNull(),
  /** Tier purchased */
  tier: varchar("tier", { length: 50 }).notNull(),
  /** Billing cycle */
  billingCycle: varchar("billingCycle", { length: 20 }).default("annual").notNull(),
  /** Number of users (for per_user tier) */
  userCount: int("userCount"),
  /** Whether LiftFlow was notified of upgrade */
  liftflowNotified: boolean("liftflowNotified").default(false).notNull(),
  /** Timestamp when LiftFlow was notified */
  liftflowNotifiedAt: timestamp("liftflowNotifiedAt"),
  /** Error message if notification failed */
  notificationError: text("notificationError"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  emailIdx: index("payment_email_idx").on(table.coachEmail),
  sessionIdx: index("checkout_session_idx").on(table.stripeCheckoutSessionId),
  paymentIntentIdx: index("payment_intent_idx").on(table.stripePaymentIntentId),
}));

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;
