CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`subscriptionId` int,
	`coachEmail` varchar(320) NOT NULL,
	`stripePaymentIntentId` varchar(255),
	`stripeCheckoutSessionId` varchar(255),
	`amount` decimal(10,2) NOT NULL,
	`currency` varchar(3) NOT NULL DEFAULT 'USD',
	`status` enum('pending','succeeded','failed','refunded') NOT NULL DEFAULT 'pending',
	`tier` enum('per_user','enterprise') NOT NULL,
	`billingCycle` enum('monthly','annual') NOT NULL,
	`userCount` int,
	`liftflowNotified` boolean NOT NULL DEFAULT false,
	`liftflowNotifiedAt` timestamp,
	`notificationError` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`coachEmail` varchar(320) NOT NULL,
	`stripeCustomerId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`tier` enum('free','per_user','enterprise') NOT NULL,
	`billingCycle` enum('monthly','annual'),
	`userCount` int DEFAULT 1,
	`status` enum('active','canceled','past_due','trialing') NOT NULL DEFAULT 'active',
	`currentPeriodStart` timestamp,
	`currentPeriodEnd` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `payment_email_idx` ON `payments` (`coachEmail`);--> statement-breakpoint
CREATE INDEX `checkout_session_idx` ON `payments` (`stripeCheckoutSessionId`);--> statement-breakpoint
CREATE INDEX `payment_intent_idx` ON `payments` (`stripePaymentIntentId`);--> statement-breakpoint
CREATE INDEX `coach_email_idx` ON `subscriptions` (`coachEmail`);--> statement-breakpoint
CREATE INDEX `stripe_customer_idx` ON `subscriptions` (`stripeCustomerId`);--> statement-breakpoint
CREATE INDEX `stripe_subscription_idx` ON `subscriptions` (`stripeSubscriptionId`);