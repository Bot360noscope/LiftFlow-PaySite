ALTER TABLE `subscriptions` ADD `cancelAt` timestamp;--> statement-breakpoint
ALTER TABLE `subscriptions` ADD `canceledAt` timestamp;