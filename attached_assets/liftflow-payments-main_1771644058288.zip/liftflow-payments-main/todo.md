# LiftFlow Payments TODO

## Database & Schema
- [x] Create payments table to track Stripe transactions
- [x] Create subscriptions table to track active subscriptions
- [x] Add indexes for efficient querying

## Stripe Integration
- [x] Request Stripe API keys (publishable and secret)
- [x] Configure Stripe webhook secret
- [x] Set up Stripe Checkout session creation
- [x] Implement webhook handler for payment events

## Pricing Page
- [x] Design pricing page layout with three tiers
- [x] Free tier: 1 user included
- [x] Pay-per-user tier: $5/month or $50/year per additional user
- [x] Enterprise tier: $1000/year for 25+ unlimited users
- [x] Add monthly/annual toggle
- [x] Implement responsive design matching LiftFlow styling

## User Identification
- [x] Accept user email/ID from URL parameters
- [x] Store user identifier in Stripe metadata
- [x] Pass user info through checkout flow

## Payment Processing
- [x] Create Stripe Checkout session endpoint
- [x] Handle payment success callback
- [x] Handle payment cancellation
- [x] Store payment records in database

## LiftFlow Integration
- [x] Create secure endpoint to call LiftFlow's upgrade API
- [x] Implement shared secret authentication
- [x] Handle webhook from Stripe to trigger LiftFlow upgrade
- [ ] Add retry logic for failed webhook calls

## UI Pages
- [x] Pricing page with tier selection
- [x] Payment confirmation page
- [x] Error handling page
- [x] Redirect back to LiftFlow after success

## Testing & Deployment
- [x] Test payment flow with Stripe test mode
- [x] Test webhook integration
- [x] Test error scenarios
- [x] Write vitest tests for critical paths
- [x] Create checkpoint for deployment

## Branding Updates
- [x] Update color scheme from blue to green
- [x] Add LiftFlow logo to all pages
- [x] Update favicon with LiftFlow branding

## New Pricing Tier
- [x] Add 10-user tier with 25% discount to products configuration
- [x] Update pricing page to show 10-user tier on annual tab only
- [x] Update checkout flow to handle 10-user tier
- [x] Update database schema if needed

## UI Improvements
- [x] Reorder pricing cards by price: Free → Pay Per User → 10 User Plan → Enterprise

## Branding Fixes
- [x] Update favicon to match LiftFlow main site (green heartbeat icon)

## Testing Improvements
- [x] Make email field editable on checkout page for standalone testing

## Content Updates
- [x] Remove "14-day free trial" text from pricing page

## Pricing Updates
- [x] Cut all prices in half

## Bug Fixes
- [x] Fix success page redirect to LiftFlow domain after payment

## Pricing Structure Changes
- [x] Remove 10-person tier from pricing configuration
- [x] Remove 10-person tier card from pricing page
- [x] Update monthly pricing display to show $30/year per user equivalent

## Webhook Integration Fixes
- [x] Review Stripe webhook handler implementation
- [x] Fix LiftFlow webhook call after successful payment
- [x] Add proper error handling and logging for webhook calls

## Layout Improvements
- [x] Center pricing cards regardless of number of tiers

## Webhook Configuration
- [ ] Verify LIFTFLOW_WEBHOOK_URL is set to production URL (https://liftflow.manus.space/api/trpc/billing.upgradeToPremium)

## Layout Fixes
- [x] Display all pricing cards in a single centered row without wrapping

## Webhook Debugging
- [ ] Review Stripe webhook handler logs
- [ ] Verify webhook is calling LiftFlow endpoint after payment
- [ ] Test end-to-end payment flow with webhook

## Pricing Text Fixes
- [x] Update "Additional users: $50/yr each" to show $25/yr
- [x] Update checkout to show additional users purchased (not total count)

## User Count Input Fixes
- [x] Change user count input to start at 1 (additional users) instead of 2 (total users)
- [x] Update minimum value to 1 instead of 2
- [x] Adjust price calculation to add 1 to user count for total

## Critical Webhook Fix
- [x] Update LIFTFLOW_WEBHOOK_URL to https://liftflow.manus.space/api/trpc/billing.upgradeToPremium
- [x] Fix userId handling - store email in Stripe metadata and use as fallback
- [x] Add detailed logging to webhook calls for debugging

## Subscription Model Conversion
- [x] Create Stripe Products for per_user tier
- [x] Create Stripe Prices for monthly and annual billing
- [x] Update products.ts with subscription pricing structure
- [x] Add subscription tracking fields to database schema
- [x] Generate and apply database migration
- [x] Update createCheckoutSession to use subscription mode
- [x] Handle customer creation and reuse in checkout
- [x] Implement subscription quantity for user count
- [x] Add customer.subscription.created webhook handler
- [x] Add customer.subscription.updated webhook handler (upgrades/downgrades)
- [x] Add customer.subscription.deleted webhook handler (cancellations)
- [x] Update LiftFlow webhook payload to send subscription data
- [x] Send subscription status (active, cancelled, past_due) to LiftFlow
- [x] Send current period end date to LiftFlow
- [x] Send user count from subscription quantity to LiftFlow
- [x] Test new subscription creation
- [x] Test upgrading user count with proration
- [x] Test downgrading user count
- [x] Test subscription cancellation
- [x] Verify LiftFlow receives correct subscription data

## Subscription Update Flow
- [x] Add getActiveSubscriptionByEmail function to db.ts
- [x] Update createCheckoutSession to check for existing subscriptions
- [x] If existing subscription found, update quantity instead of creating new subscription
- [x] Handle Stripe subscription update with proration
- [x] Test upgrading from 5 users to 10 users mid-cycle
- [x] Verify prorated charge is calculated correctly
- [x] Ensure all users renew on the same date

## Fixed Tier Pricing Restructure
- [x] Design new pricing structure with volume discounts (5, 10, 25 users)
- [x] Remove monthly billing option (annual-only)
- [x] Create Stripe products for 5-user tier
- [x] Create Stripe products for 10-user tier
- [x] Create Stripe products for 25-user tier
- [x] Update Enterprise tier pricing
- [x] Update products.ts with new fixed tier structure
- [x] Remove billing cycle toggle from pricing page
- [x] Update pricing cards to show 5 tiers (Free, 5, 10, 25, Enterprise)
- [x] Show per-user cost decreasing with scale
- [x] Update checkout flow to handle fixed tier selection
- [x] Remove user count input (fixed quantities only)
- [x] Test all 5 tiers end-to-end

## Webhook Integration Debugging
- [x] Check webhook logs for recent payment attempts
- [x] Verify Stripe webhook events are being sent
- [x] Check if webhook handler is processing new tier names correctly
- [x] Fix invalid date error in webhook handler
- [x] Test webhook call to LiftFlow manually
- [x] Verify LiftFlow endpoint is receiving and processing webhook data
- [x] Fix safe date parsing in subscription.updated handler

## Fix periodEnd Date
- [x] Calculate periodEnd from durationDays instead of Stripe current_period_end
- [x] Ensure future dates are sent for both test and production modes

## Fix Card Payment Form
- [x] Add payment_method_types to Stripe checkout session
- [x] Verify card form appears on Stripe checkout page

## Fix Subscription Upgrade Tier
- [x] Extract new tier from Stripe subscription metadata in subscription.updated handler
- [x] Update database with new tier when subscription is updated
- [x] Send new tier to LiftFlow instead of old tier from database

## Fix Current Subscription Detection
- [x] Remove any UI restrictions on pricing page tier selection
- [x] Make all tier buttons clickable regardless of current plan
- [x] Let Stripe handle upgrade/downgrade logic automatically
- [x] Add reassuring note about duplicate plan selection

## Fix Free Tier Button
- [x] Change button text from "Current Plan" to "Get Started"
- [x] Remove disabled state from Free tier button

## Fix Free Tier Clickability
- [x] Update handleSelectPlan to allow Free tier clicks
- [x] Show appropriate message when Free tier is selected

## Enable Free Tier Downgrades
- [x] Remove toast notification from Free tier click handler
- [x] Allow Free tier to navigate to checkout like paid tiers
- [x] Update checkout to handle Free tier as cancellation/downgrade
- [x] Add cancelSubscription procedure to billing router
- [x] Update checkout UI for cancellation flow

## Fix Cancellation Webhook
- [x] Update cancelSubscription to notify LiftFlow when downgrading to Free
- [x] Send webhook with tier="free", status="cancelled", userCount=1
- [ ] Test end-to-end cancellation flow from payment site to coaching app
