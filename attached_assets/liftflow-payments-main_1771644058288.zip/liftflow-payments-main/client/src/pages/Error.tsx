import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { XCircle, ArrowLeft, RefreshCw } from "lucide-react";
import { useLocation } from "wouter";

export default function Error() {
  const [, navigate] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const errorMessage = params.get("message") || "An unexpected error occurred";
  const userId = params.get("userId");
  const email = params.get("email");

  const handleTryAgain = () => {
    const queryParams = new URLSearchParams();
    if (userId) queryParams.set("userId", userId);
    if (email) queryParams.set("email", email);
    navigate(`/pricing?${queryParams.toString()}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center">
            <XCircle className="h-10 w-10 text-red-600 dark:text-red-400" />
          </div>
          <CardTitle className="text-3xl">Payment Failed</CardTitle>
          <CardDescription className="text-lg">
            We couldn't process your payment
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Error Message */}
          <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
            <p className="text-sm text-destructive font-medium">{errorMessage}</p>
          </div>

          {/* Common Issues */}
          <div className="space-y-4">
            <h3 className="font-semibold">Common Issues:</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Insufficient funds or card declined</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Incorrect card details or expired card</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Payment blocked by your bank (try contacting them)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Network or connection issues</span>
              </li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              size="lg"
              className="flex-1"
              onClick={handleTryAgain}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Try Again
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="flex-1"
              onClick={() => {
                window.location.href = "https://YOUR-LIFTFLOW-DOMAIN.manus.space";
              }}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Return to LiftFlow
            </Button>
          </div>

          {/* Support */}
          <div className="text-center text-sm text-muted-foreground">
            <p>Need help? Contact us at <a href="mailto:support@liftflow.app" className="text-primary hover:underline">support@liftflow.app</a></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
