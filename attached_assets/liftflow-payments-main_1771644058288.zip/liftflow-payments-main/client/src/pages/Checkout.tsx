import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ArrowLeft, Check } from "lucide-react";
import { getPricingPlan, type PricingTier } from "@shared/products";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Link, useLocation } from "wouter";

export default function Checkout() {
  const [, navigate] = useLocation();
  const params = new URLSearchParams(window.location.search);
  
  const userId = params.get("userId");
  const emailParam = params.get("email");
  const [email, setEmail] = useState(emailParam || "");
  const tierParam = (params.get("tier") || "tier_5") as PricingTier;
  
  const plan = getPricingPlan(tierParam);
  
  if (!plan) {
    navigate("/pricing");
    return null;
  }
  
  // Special handling for Free tier (cancellation/downgrade)
  const isFreeDowngrade = plan.id === "free";
  
  const cancelSubscription = trpc.billing.cancelSubscription.useMutation({
    onSuccess: () => {
      toast.success("Subscription cancelled successfully. You've been downgraded to the Free plan.");
      setTimeout(() => {
        navigate("/");
      }, 2000);
    },
    onError: (error: { message?: string }) => {
      toast.error(error.message || "Failed to cancel subscription");
    },
  });

  const createCheckout = trpc.billing.createCheckoutSession.useMutation({
    onSuccess: (data: { url: string; sessionId: string; message?: string; subscriptionId?: string }) => {
      if (data.message && data.subscriptionId) {
        // Subscription was updated, no checkout needed
        toast.success(data.message);
        setTimeout(() => {
          navigate("/");
        }, 2000);
      } else if (data.url) {
        // New subscription, redirect to Stripe Checkout
        toast.success("Redirecting to checkout...");
        window.open(data.url, "_blank");
      }
    },
    onError: (error: { message?: string }) => {
      toast.error(error.message || "Failed to create checkout session");
    },
  });

  const handleCheckout = () => {
    if (!email || !email.trim()) {
      toast.error("Email is required");
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    // Handle Free tier as subscription cancellation
    if (plan.id === "free") {
      cancelSubscription.mutate({ coachEmail: email });
      return;
    }
    
    createCheckout.mutate({
      tier: plan.id as "tier_5" | "tier_10" | "tier_25" | "enterprise",
      userCount: plan.userCount,
      coachEmail: email,
      userId: userId || undefined,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <svg className="h-5 w-5 text-primary-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
            </div>
            <span className="font-bold text-xl">LiftFlow</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container max-w-4xl py-12">
        <Link href="/pricing">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Pricing
          </Button>
        </Link>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Order Summary */}
          <Card>
            <CardHeader>
              <CardTitle>{isFreeDowngrade ? "Cancel Subscription" : "Order Summary"}</CardTitle>
              <CardDescription>{isFreeDowngrade ? "Downgrade to Free plan" : "Review your selected plan"}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {isFreeDowngrade ? (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    You're about to cancel your paid subscription and downgrade to the Free plan.
                  </p>
                  <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                    <p className="text-sm font-medium">What happens next:</p>
                    <ul className="text-sm space-y-1 list-disc list-inside text-muted-foreground">
                      <li>Your paid features will remain active until the end of your billing period</li>
                      <li>You'll be automatically downgraded to Free when your subscription expires</li>
                      <li>No refunds will be issued for the remaining period</li>
                      <li>You can upgrade again anytime</li>
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-semibold text-lg">{plan.name}</div>
                    <div className="text-sm text-muted-foreground">{plan.description}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-xl">${plan.annualPrice}</div>
                    <div className="text-xs text-muted-foreground">/year</div>
                  </div>
                </div>
              )}

              {!isFreeDowngrade && (
                <>
                  <div className="border-t pt-4">
                    <div className="text-sm font-medium mb-3">Included features:</div>
                    <ul className="space-y-2">
                      {plan.features.map((feature: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between text-sm">
                      <span>Billing cycle</span>
                      <span className="font-medium">Annual</span>
                    </div>
                    {plan.id !== "enterprise" && (
                      <div className="flex justify-between text-sm mt-2">
                        <span>Cost per user</span>
                        <span className="font-medium">${plan.pricePerUser}/year</span>
                      </div>
                    )}
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Total due today</span>
                      <span className="font-bold text-2xl">${plan.annualPrice}</span>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Payment Form */}
          <Card>
            <CardHeader>
              <CardTitle>{isFreeDowngrade ? "Confirm Cancellation" : "Payment Details"}</CardTitle>
              <CardDescription>{isFreeDowngrade ? "Enter your email to confirm cancellation" : "Enter your email to continue to payment"}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="coach@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={createCheckout.isPending}
                />
                <p className="text-xs text-muted-foreground">
                  We'll send your receipt and account details to this email
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                onClick={handleCheckout}
                disabled={(isFreeDowngrade ? cancelSubscription.isPending : createCheckout.isPending) || !email}
                className="w-full"
                size="lg"
                variant={isFreeDowngrade ? "destructive" : "default"}
              >
                {(isFreeDowngrade ? cancelSubscription.isPending : createCheckout.isPending) ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : isFreeDowngrade ? (
                  "Cancel Subscription"
                ) : (
                  "Proceed to Payment"
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Trust Signals */}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>🔒 Secure payment powered by Stripe</p>
          <p className="mt-2">Cancel anytime • No hidden fees • 30-day money-back guarantee</p>
        </div>
      </div>
    </div>
  );
}
