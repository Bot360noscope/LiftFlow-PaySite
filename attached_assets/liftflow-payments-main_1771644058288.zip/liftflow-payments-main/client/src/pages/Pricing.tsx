import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";
import { PRICING_PLANS, calculateSavings, type PricingTier } from "@shared/products";
import { Link, useLocation } from "wouter";

export default function Pricing() {
  const [, navigate] = useLocation();
  
  // Extract user info from URL params
  const params = new URLSearchParams(window.location.search);
  const userId = params.get("userId");
  const email = params.get("email");

  const handleSelectPlan = (tier: PricingTier) => {
    // Navigate to checkout with user info and selected tier (including Free for downgrades)
    const checkoutParams = new URLSearchParams();
    if (userId) checkoutParams.set("userId", userId);
    if (email) checkoutParams.set("email", email);
    checkoutParams.set("tier", tier);
    
    navigate(`/checkout?${checkoutParams.toString()}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <svg className="h-5 w-5 text-primary-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
            </div>
            <span className="font-bold text-xl">LiftFlow</span>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Choose Your Plan
            </h1>
            <p className="text-lg text-muted-foreground">
              Scale your coaching business with flexible pricing that grows with you
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Annual billing only • Save more as you scale
            </p>
          </div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 max-w-7xl mx-auto">
            {PRICING_PLANS.map((plan) => {
              const savings = calculateSavings(plan.id);
              
              return (
                <Card
                  key={plan.id}
                  className={`relative flex flex-col ${
                    plan.popular
                      ? "border-primary shadow-lg scale-105 md:scale-110"
                      : "border-border"
                  }`}
                >
                  {plan.popular && (
                    <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                      Most Popular
                    </Badge>
                  )}
                  
                  <CardHeader>
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                  </CardHeader>
                  
                  <CardContent className="flex-1">
                    <div className="mb-6">
                      {plan.id === "free" ? (
                        <div className="text-4xl font-bold">Free</div>
                      ) : plan.id === "enterprise" ? (
                        <>
                          <div className="text-4xl font-bold">${plan.annualPrice}</div>
                          <div className="text-sm text-muted-foreground">/year</div>
                        </>
                      ) : (
                        <>
                          <div className="text-4xl font-bold">${plan.annualPrice}</div>
                          <div className="text-sm text-muted-foreground">/year</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            ${plan.pricePerUser}/user/year
                          </div>
                          {savings > 0 && (
                            <Badge variant="outline" className="mt-2 bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800">
                              Save {savings}%
                            </Badge>
                          )}
                        </>
                      )}
                    </div>
                    
                    <ul className="space-y-3">
                      {plan.features.map((feature: string, index: number) => (
                        <li key={index} className="flex items-start gap-2">
                          <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  
                  <CardFooter>
                    <Button
                      onClick={() => handleSelectPlan(plan.id)}
                      variant={plan.popular ? "default" : "outline"}
                      className="w-full"
                    >
                      Get Started
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>

          {/* FAQ or Additional Info */}
          <div className="mt-16 text-center max-w-2xl mx-auto space-y-4">
            <p className="text-sm text-muted-foreground">
              All plans include unlimited workout programs, mobile app access, and email support.
              <br />
              Need more than 25 users? Choose Enterprise for unlimited access.
            </p>
            <p className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-3 border border-border">
              💡 Already have a plan? Don't worry - selecting the same tier won't charge you twice. Stripe automatically handles upgrades and downgrades.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
