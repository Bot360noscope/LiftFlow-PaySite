import { Request, Response } from "express";

/**
 * Webhook endpoint for LiftFlow to receive payment notifications from payment site
 * POST /api/webhooks/payment
 * 
 * Expected payload:
 * {
 *   webhookSecret: string,
 *   email: string,
 *   plan: "per_user" | "enterprise",
 *   durationDays: number,
 *   userCount?: number
 * }
 * 
 * This is a simple endpoint that the payment site calls after successful Stripe checkout.
 * It validates the webhook secret and returns success. In a real implementation, this would
 * update the user's premium status in LiftFlow's database.
 */
export async function handlePaymentWebhook(req: Request, res: Response) {
  try {
    const { webhookSecret, email, plan, durationDays, userCount } = req.body;

    console.log("[Payment Webhook] Received payment notification:", {
      email,
      plan,
      durationDays,
      userCount,
    });

    // Verify webhook secret
    const expectedSecret = process.env.LIFTFLOW_WEBHOOK_SECRET;
    if (!expectedSecret) {
      console.error("[Payment Webhook] LIFTFLOW_WEBHOOK_SECRET not configured");
      return res.status(500).json({ 
        success: false, 
        error: "Webhook secret not configured" 
      });
    }

    if (webhookSecret !== expectedSecret) {
      console.error("[Payment Webhook] Invalid webhook secret");
      return res.status(401).json({ 
        success: false, 
        error: "Invalid webhook secret" 
      });
    }

    // Validate required fields
    if (!email || !plan || !durationDays) {
      console.error("[Payment Webhook] Missing required fields:", { email, plan, durationDays });
      return res.status(400).json({ 
        success: false, 
        error: "Missing required fields: email, plan, durationDays" 
      });
    }

    // TODO: In LiftFlow, this would update the user's premium status
    // For now, just log and return success
    console.log("[Payment Webhook] Payment notification processed successfully:", {
      email,
      plan,
      expiresInDays: durationDays,
      maxUsers: userCount || (plan === "enterprise" ? 999 : 2),
    });

    return res.json({ 
      success: true,
      message: "Payment notification received",
      email,
      plan,
    });

  } catch (error) {
    console.error("[Payment Webhook] Error processing webhook:", error);
    return res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : "Unknown error" 
    });
  }
}
