import type { Request, Response } from "express";
import Stripe from "stripe";
import {
  createSubscription,
  updateSubscription,
  getSubscriptionByStripeId,
} from "../db";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2026-01-28.clover",
});

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

/**
 * Notify LiftFlow backend about subscription changes
 * Sends email, plan, userCount, status, and period end to LiftFlow
 */
async function notifyLiftFlow(subscription: {
  coachEmail: string;
  tier: string;
  userCount: number;
  status: string;
  currentPeriodEnd: Date;
  billingCycle: string;
}) {
  const liftflowWebhookUrl = process.env.LIFTFLOW_WEBHOOK_URL;
  const liftflowSecret = process.env.LIFTFLOW_WEBHOOK_SECRET;

  if (!liftflowWebhookUrl || !liftflowSecret) {
    console.error("[Webhook] LiftFlow webhook URL or secret not configured");
    return { success: false, error: "LiftFlow webhook not configured" };
  }

  // Calculate duration based on billing cycle
  const durationDays = subscription.billingCycle === "monthly" ? 30 : 365;

  // Calculate a proper future periodEnd date
  // Use durationDays from now instead of Stripe's current_period_end
  // which may be undefined/past in test mode
  const periodEnd = new Date();
  periodEnd.setDate(periodEnd.getDate() + durationDays);

  // Build the payload
  const payload = {
    webhookSecret: liftflowSecret,
    email: subscription.coachEmail,
    plan: subscription.tier,
    userCount: subscription.userCount,
    durationDays,
    status: subscription.status,
    periodEnd: periodEnd.toISOString(),
  };

  console.log("[Webhook] Calling LiftFlow webhook:", {
    url: liftflowWebhookUrl,
    payload: { ...payload, webhookSecret: "[REDACTED]" },
  });

  try {
    const response = await fetch(liftflowWebhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const responseText = await response.text();
    console.log("[Webhook] LiftFlow response status:", response.status);
    console.log("[Webhook] LiftFlow response body:", responseText);

    if (!response.ok) {
      console.error("[Webhook] LiftFlow notification failed:", response.status, responseText);
      return {
        success: false,
        error: `HTTP ${response.status}: ${responseText}`,
      };
    }

    let result;
    try {
      result = JSON.parse(responseText);
    } catch {
      result = responseText;
    }
    console.log("[Webhook] LiftFlow notified successfully:", result);
    return { success: true };
  } catch (error) {
    console.error("[Webhook] Failed to notify LiftFlow:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Handle Stripe webhook events
 */
export async function handleStripeWebhook(req: Request, res: Response) {
  const sig = req.headers["stripe-signature"];

  if (!sig) {
    console.error("[Webhook] Missing stripe-signature header");
    return res.status(400).json({ error: "Missing signature" });
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error("[Webhook] Signature verification failed:", err);
    return res.status(400).json({ error: "Invalid signature" });
  }

  // Handle test events
  if (event.id.startsWith("evt_test_")) {
    console.log("[Webhook] Test event detected, returning verification response");
    return res.json({
      verified: true,
    });
  }

  console.log("[Webhook] Received event:", event.type, event.id);

  try {
    switch (event.type) {
      case "customer.subscription.created": {
        const subscription = event.data.object as Stripe.Subscription;
        
        console.log("[Webhook] Subscription created:", subscription.id);
        console.log("[Webhook] Subscription metadata:", subscription.metadata);

        const customer = await stripe.customers.retrieve(subscription.customer as string);
        const coachEmail = (customer as Stripe.Customer).email || subscription.metadata.coachEmail;

        if (!coachEmail) {
          console.error("[Webhook] No email found for subscription:", subscription.id);
          return res.status(400).json({ error: "Missing customer email" });
        }

        const tier = subscription.metadata.tier || "tier_5";
        const billingCycle = subscription.metadata.billingCycle || "annual";
        const userCount = parseInt(subscription.metadata.userCount || "1");

        // Safely parse period dates from Stripe subscription
        // Stripe API may use different property names depending on version
        const sub = subscription as any;
        const periodStartRaw = sub.current_period_start || sub.currentPeriodStart;
        const periodEndRaw = sub.current_period_end || sub.currentPeriodEnd;
        
        console.log("[Webhook] Period start raw:", periodStartRaw, "Period end raw:", periodEndRaw);
        console.log("[Webhook] Subscription keys:", Object.keys(sub).filter(k => k.includes('period') || k.includes('Period')));
        
        // Handle both unix timestamp (number) and ISO string formats
        const parsePeriodDate = (val: any): Date => {
          if (!val) return new Date(); // fallback to now
          if (typeof val === 'number') {
            // Unix timestamps from Stripe are in seconds
            return new Date(val * 1000);
          }
          if (typeof val === 'string') {
            return new Date(val);
          }
          if (val instanceof Date) {
            return val;
          }
          return new Date();
        };
        
        const currentPeriodStart = parsePeriodDate(periodStartRaw);
        const currentPeriodEnd = parsePeriodDate(periodEndRaw);
        
        console.log("[Webhook] Parsed period start:", currentPeriodStart.toISOString());
        console.log("[Webhook] Parsed period end:", currentPeriodEnd.toISOString());

        // Create subscription record in database
        await createSubscription({
          coachEmail,
          stripeCustomerId: subscription.customer as string,
          stripeSubscriptionId: subscription.id,
          tier,
          billingCycle,
          userCount,
          status: "active",
          currentPeriodStart,
          currentPeriodEnd,
        });

        // Notify LiftFlow
        await notifyLiftFlow({
          coachEmail,
          tier,
          userCount,
          status: "active",
          currentPeriodEnd,
          billingCycle,
        });

        console.log("[Webhook] Subscription created and LiftFlow notified");
        break;
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        
        console.log("[Webhook] Subscription updated:", subscription.id);

        const dbSubscription = await getSubscriptionByStripeId(subscription.id);
        
        if (!dbSubscription) {
          console.error("[Webhook] Subscription not found in database:", subscription.id);
          return res.status(404).json({ error: "Subscription not found" });
        }

        // Extract new tier and userCount from subscription metadata
        const newTier = (subscription as any).metadata?.tier || dbSubscription.tier;
        const newUserCount = parseInt((subscription as any).metadata?.userCount || '1', 10);
        const quantity = subscription.items.data[0]?.quantity || 1;

        // Safely parse period dates
        const subU = subscription as any;
        const periodStartRawU = subU.current_period_start || subU.currentPeriodStart;
        const periodEndRawU = subU.current_period_end || subU.currentPeriodEnd;
        
        const parseDateSafe = (val: any): Date => {
          if (!val) return new Date();
          if (typeof val === 'number') return new Date(val * 1000);
          if (typeof val === 'string') return new Date(val);
          if (val instanceof Date) return val;
          return new Date();
        };

        // Update subscription in database with new tier
        const updateData: any = {
          tier: newTier,
          userCount: newUserCount,
          status: subscription.status,
          currentPeriodStart: parseDateSafe(periodStartRawU),
          currentPeriodEnd: parseDateSafe(periodEndRawU),
        };
        
        // Only set cancel dates if they exist
        if (subU.cancel_at) {
          updateData.cancelAt = parseDateSafe(subU.cancel_at);
        }
        if (subU.canceled_at) {
          updateData.canceledAt = parseDateSafe(subU.canceled_at);
        }
        
        await updateSubscription(subscription.id, updateData);

        // Notify LiftFlow of the update with new tier
        await notifyLiftFlow({
          coachEmail: dbSubscription.coachEmail,
          tier: newTier,
          userCount: newUserCount,
          status: subscription.status,
          currentPeriodEnd: parseDateSafe(periodEndRawU),
          billingCycle: dbSubscription.billingCycle || "annual",
        });

        console.log("[Webhook] Subscription updated and LiftFlow notified");
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        
        console.log("[Webhook] Subscription deleted:", subscription.id);

        const dbSubscription = await getSubscriptionByStripeId(subscription.id);
        
        if (!dbSubscription) {
          console.error("[Webhook] Subscription not found in database:", subscription.id);
          return res.status(404).json({ error: "Subscription not found" });
        }

        // Update subscription status to canceled
        await updateSubscription(subscription.id, {
          status: "canceled",
          canceledAt: new Date(),
        });

        // Notify LiftFlow that subscription was canceled
        await notifyLiftFlow({
          coachEmail: dbSubscription.coachEmail,
          tier: dbSubscription.tier,
          userCount: 0, // No more slots
          status: "canceled",
          currentPeriodEnd: new Date(),
          billingCycle: dbSubscription.billingCycle || "annual",
        });

        console.log("[Webhook] Subscription deleted and LiftFlow notified");
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        console.log("[Webhook] Invoice payment succeeded:", invoice.id);
        // Subscription renewal - no action needed, subscription.updated will handle it
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        console.log("[Webhook] Invoice payment failed:", invoice.id);
        
        const subscriptionId = (invoice as any).subscription;
        if (subscriptionId) {
          const dbSubscription = await getSubscriptionByStripeId(subscriptionId as string);
          if (dbSubscription) {
            await updateSubscription(subscriptionId as string, {
              status: "past_due",
            });
          }
        }
        break;
      }

      default:
        console.log("[Webhook] Unhandled event type:", event.type);
    }

    res.json({ received: true });
  } catch (error) {
    console.error("[Webhook] Error processing event:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
}
