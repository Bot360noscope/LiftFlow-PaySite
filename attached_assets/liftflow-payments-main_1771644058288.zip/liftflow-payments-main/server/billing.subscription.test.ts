import { describe, it, expect } from "vitest";
import { billingRouter } from "./routers/billing";

describe("Subscription Checkout", () => {
  it("should create checkout session for tier_5 with correct user count", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "tier_5",
      userCount: 5,
      coachEmail: "test@example.com",
      userId: "test-user-123",
    });

    expect(result).toHaveProperty("url");
    expect(result).toHaveProperty("sessionId");
    expect(result.url).toContain("checkout.stripe.com");
  });

  it("should reject invalid tier name", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    await expect(
      caller.createCheckoutSession({
        tier: "invalid_tier" as any,
        userCount: 5,
        coachEmail: "test@example.com",
      })
    ).rejects.toThrow();
  });

  it("should create checkout session for enterprise tier", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "enterprise",
      userCount: 999,
      coachEmail: "test@example.com",
    });

    expect(result).toHaveProperty("url");
    expect(result).toHaveProperty("sessionId");
    expect(result.url).toContain("checkout.stripe.com");
  });

  it("should create checkout session for tier_10", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "tier_10",
      userCount: 10,
      coachEmail: "test@example.com",
    });

    expect(result).toHaveProperty("url");
    expect(result).toHaveProperty("sessionId");
    expect(result.url).toContain("checkout.stripe.com");
  });

  it("should create checkout session for tier_25", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "tier_25",
      userCount: 25,
      coachEmail: "test@example.com",
    });

    expect(result).toHaveProperty("url");
    expect(result).toHaveProperty("sessionId");
    expect(result.url).toContain("checkout.stripe.com");
  });
});
