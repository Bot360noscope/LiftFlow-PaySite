import { describe, it, expect, beforeAll } from "vitest";
import { billingRouter } from "./routers/billing";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2026-01-28.clover",
});

describe("Subscription Update Flow", () => {
  let testEmail: string;
  let firstSubscriptionId: string;

  beforeAll(() => {
    testEmail = `test-${Date.now()}@example.com`;
  });

  it("should create initial subscription for new user", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "per_user",
      billingCycle: "annual",
      userCount: 5,
      coachEmail: testEmail,
    });

    expect(result).toHaveProperty("url");
    expect(result.url).toContain("checkout.stripe.com");
  });

  it("should detect existing subscription and update quantity", async () => {
    // First, create a subscription manually
    const customer = await stripe.customers.create({
      email: testEmail,
    });

    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [
        {
          price: "price_1T0PKYE4Zd9PkPJCV7kK4BqU", // per_user annual
          quantity: 5,
        },
      ],
      metadata: {
        tier: "per_user",
        billingCycle: "annual",
        userCount: "5",
        coachEmail: testEmail,
      },
    });

    firstSubscriptionId = subscription.id;

    // Store subscription in database
    const { createSubscription } = await import("./db");
    await createSubscription({
      stripeSubscriptionId: subscription.id,
      stripeCustomerId: customer.id,
      coachEmail: testEmail,
      tier: "per_user",
      billingCycle: "annual",
      userCount: 5,
      status: "active",
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
    });

    // Now try to "checkout" again with more users
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "per_user",
      billingCycle: "annual",
      userCount: 10, // Upgrading from 5 to 10
      coachEmail: testEmail,
    });

    // Should return update confirmation, not checkout URL
    expect(result).toHaveProperty("message");
    expect(result).toHaveProperty("subscriptionId");
    expect(result.url).toBe("");
    expect(result.message).toContain("Subscription updated successfully");

    // Verify subscription was actually updated in Stripe
    const updatedSubscription = await stripe.subscriptions.retrieve(firstSubscriptionId);
    expect(updatedSubscription.items.data[0].quantity).toBe(10);
  });
});
