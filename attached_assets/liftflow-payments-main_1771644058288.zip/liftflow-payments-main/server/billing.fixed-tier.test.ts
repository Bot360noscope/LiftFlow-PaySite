import { describe, it, expect } from "vitest";
import { billingRouter } from "./routers/billing";

describe("Fixed Tier Checkout Flow", () => {
  it("should create checkout session for 5-user tier", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "tier_5",
      userCount: 5,
      coachEmail: `test-tier5-${Date.now()}@example.com`,
    });

    expect(result).toHaveProperty("url");
    expect(result.url).toContain("checkout.stripe.com");
  });

  it("should create checkout session for 10-user tier", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "tier_10",
      userCount: 10,
      coachEmail: `test-tier10-${Date.now()}@example.com`,
    });

    expect(result).toHaveProperty("url");
    expect(result.url).toContain("checkout.stripe.com");
  });

  it("should create checkout session for 25-user tier", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "tier_25",
      userCount: 25,
      coachEmail: `test-tier25-${Date.now()}@example.com`,
    });

    expect(result).toHaveProperty("url");
    expect(result.url).toContain("checkout.stripe.com");
  });

  it("should create checkout session for enterprise tier", async () => {
    const caller = billingRouter.createCaller({
      req: {
        headers: {
          origin: "http://localhost:3000",
        },
      } as any,
      res: {} as any,
      user: null,
    });

    const result = await caller.createCheckoutSession({
      tier: "enterprise",
      userCount: 999,
      coachEmail: `test-enterprise-${Date.now()}@example.com`,
    });

    expect(result).toHaveProperty("url");
    expect(result.url).toContain("checkout.stripe.com");
  });
});
