import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import Stripe from "stripe";
import { getActiveSubscriptionByEmail } from "../db";
import { STRIPE_PRICE_IDS, type PricingTier } from "@shared/products";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2026-01-28.clover",
});

export const billingRouter = router({
  createCheckoutSession: publicProcedure
    .input(
      z.object({
        tier: z.enum(["tier_5", "tier_10", "tier_25", "enterprise"]),
        userCount: z.number().min(1),
        coachEmail: z.string().email(),
        userId: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const { tier, userCount, coachEmail, userId } = input;

        // Get the appropriate price ID
        const priceId = STRIPE_PRICE_IDS[tier as keyof typeof STRIPE_PRICE_IDS];

        if (!priceId) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Invalid pricing configuration",
          });
        }

        // Check if user already has an active subscription
        const existingSubscription = await getActiveSubscriptionByEmail(coachEmail);
        
        if (existingSubscription && existingSubscription.stripeSubscriptionId) {
          // Update existing subscription instead of creating new one
          const subscription = await stripe.subscriptions.retrieve(
            existingSubscription.stripeSubscriptionId
          );
          
          // Update subscription with new tier/price
          const updatedSubscription = await stripe.subscriptions.update(
            existingSubscription.stripeSubscriptionId,
            {
              items: [
                {
                  id: subscription.items.data[0].id,
                  price: priceId,
                  quantity: 1, // Fixed tiers always have quantity 1
                },
              ],
              proration_behavior: "create_prorations",
              metadata: {
                tier,
                userCount: userCount.toString(),
                coachEmail,
                userId: userId || "",
              },
            }
          );
          
          return {
            url: "", // Empty string instead of null for existing subscription
            sessionId: "",
            subscriptionId: updatedSubscription.id,
            message: "Subscription updated successfully. Prorated charges will appear on your next invoice.",
          };
        }

        // Find or create Stripe customer
        let customer: Stripe.Customer;
        const existingCustomers = await stripe.customers.list({
          email: coachEmail,
          limit: 1,
        });

        if (existingCustomers.data.length > 0) {
          customer = existingCustomers.data[0];
        } else {
          customer = await stripe.customers.create({
            email: coachEmail,
            metadata: {
              userId: userId || "",
              coachEmail,
            },
          });
        }

        // Create Stripe Checkout Session for new subscription
        const session = await stripe.checkout.sessions.create({
          mode: "subscription",
          payment_method_types: ["card"],
          customer: customer.id,
          client_reference_id: userId || coachEmail,
          line_items: [
            {
              price: priceId,
              quantity: 1, // Fixed tiers always have quantity 1
            },
          ],
          subscription_data: {
            metadata: {
              tier,
              userCount: userCount.toString(),
              coachEmail,
              userId: userId || "",
            },
          },
          metadata: {
            tier,
            userCount: userCount.toString(),
            coachEmail,
            userId: userId || "",
          },
          success_url: `${ctx.req.headers.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${ctx.req.headers.origin}/pricing?userId=${userId || ""}&email=${coachEmail}`,
          allow_promotion_codes: true,
        });

        return {
          url: session.url!,
          sessionId: session.id,
        };
      } catch (error) {
        console.error("[Billing] Failed to create checkout session:", error);
        
        if (error instanceof TRPCError) {
          throw error;
        }
        
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create checkout session",
        });
      }
    }),

  cancelSubscription: publicProcedure
    .input(
      z.object({
        coachEmail: z.string().email(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const { coachEmail } = input;

        // Find active subscription
        const existingSubscription = await getActiveSubscriptionByEmail(coachEmail);
        
        if (!existingSubscription || !existingSubscription.stripeSubscriptionId) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "No active subscription found for this email",
          });
        }

        // Cancel subscription at period end (not immediately)
        await stripe.subscriptions.update(
          existingSubscription.stripeSubscriptionId,
          {
            cancel_at_period_end: true,
          }
        );

        // Notify LiftFlow about the downgrade to Free
        const liftflowWebhookUrl = process.env.LIFTFLOW_WEBHOOK_URL;
        const liftflowSecret = process.env.LIFTFLOW_WEBHOOK_SECRET;

        if (liftflowWebhookUrl && liftflowSecret) {
          const payload = {
            webhookSecret: liftflowSecret,
            email: coachEmail,
            plan: "free",
            userCount: 1,
            durationDays: 0, // Immediate downgrade at period end
            status: "cancelled",
            periodEnd: new Date().toISOString(),
          };

          console.log("[Billing] Notifying LiftFlow of cancellation:", {
            url: liftflowWebhookUrl,
            email: coachEmail,
          });

          try {
            const response = await fetch(liftflowWebhookUrl, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(payload),
            });

            const responseText = await response.text();
            console.log("[Billing] LiftFlow response:", response.status, responseText);

            if (!response.ok) {
              console.error("[Billing] LiftFlow notification failed:", response.status, responseText);
            } else {
              console.log("[Billing] LiftFlow notified successfully of cancellation");
            }
          } catch (error) {
            console.error("[Billing] Failed to notify LiftFlow:", error);
            // Don't throw - cancellation succeeded even if notification failed
          }
        } else {
          console.warn("[Billing] LiftFlow webhook not configured, skipping notification");
        }

        return {
          success: true,
          message: "Subscription will be cancelled at the end of the billing period",
        };
      } catch (error) {
        console.error("[Billing] Failed to cancel subscription:", error);
        
        if (error instanceof TRPCError) {
          throw error;
        }
        
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to cancel subscription",
        });
      }
    }),
});
