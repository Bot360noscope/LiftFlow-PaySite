import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock Stripe
vi.mock("stripe", () => {
  const mockStripe = {
    checkout: {
      sessions: {
        create: vi.fn().mockResolvedValue({
          id: "cs_test_123",
          url: "https://checkout.stripe.com/test",
          customer: "cus_test_123",
          payment_intent: "pi_test_123",
        }),
      },
    },
    webhooks: {
      constructEvent: vi.fn(),
    },
  };
  
  return {
    default: vi.fn(() => mockStripe),
  };
});

// Mock database functions
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue({}),
  upsertUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  createPayment: vi.fn().mockResolvedValue({ insertId: 1 }),
  getPaymentByCheckoutSession: vi.fn(),
  updatePaymentStatus: vi.fn(),
  markPaymentNotified: vi.fn(),
  createSubscription: vi.fn(),
  getSubscriptionByEmail: vi.fn(),
  updateSubscription: vi.fn(),
}));

function createTestContext(): TrpcContext {
  return {
    user: undefined,
    req: {
      protocol: "https",
      headers: {
        origin: "https://test.manus.space",
      },
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("billing.createCheckoutSession", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("creates checkout session for pay-per-user tier with valid input", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.billing.createCheckoutSession({
      tier: "per_user",
      billingCycle: "monthly",
      userCount: 5,
      coachEmail: "coach@example.com",
      userId: "user123",
    });

    expect(result).toHaveProperty("url");
    expect(result).toHaveProperty("sessionId");
    expect(result.url).toBe("https://checkout.stripe.com/test");
    expect(result.sessionId).toBe("cs_test_123");
  });

  it("creates checkout session for enterprise tier", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.billing.createCheckoutSession({
      tier: "enterprise",
      billingCycle: "annual",
      userCount: 50,
      coachEmail: "enterprise@example.com",
    });

    expect(result).toHaveProperty("url");
    expect(result).toHaveProperty("sessionId");
  });

  it("rejects pay-per-user tier with less than 2 users", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.billing.createCheckoutSession({
        tier: "per_user",
        billingCycle: "monthly",
        userCount: 1,
        coachEmail: "coach@example.com",
      })
    ).rejects.toThrow("Pay-per-user tier requires at least 2 users");
  });

  it("rejects enterprise tier with less than 25 users", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.billing.createCheckoutSession({
        tier: "enterprise",
        billingCycle: "annual",
        userCount: 10,
        coachEmail: "coach@example.com",
      })
    ).rejects.toThrow("Enterprise tier requires at least 25 users");
  });

  it("validates email format", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.billing.createCheckoutSession({
        tier: "per_user",
        billingCycle: "monthly",
        userCount: 5,
        coachEmail: "invalid-email",
      })
    ).rejects.toThrow();
  });

  it("calculates correct price for pay-per-user monthly", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // 5 users, first is free, so 4 * $5 = $20
    const result = await caller.billing.createCheckoutSession({
      tier: "per_user",
      billingCycle: "monthly",
      userCount: 5,
      coachEmail: "coach@example.com",
    });

    expect(result).toBeDefined();
  });

  it("calculates correct price for pay-per-user annual", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // 3 users, first is free, so 2 * $50 = $100
    const result = await caller.billing.createCheckoutSession({
      tier: "per_user",
      billingCycle: "annual",
      userCount: 3,
      coachEmail: "coach@example.com",
    });

    expect(result).toBeDefined();
  });
});
