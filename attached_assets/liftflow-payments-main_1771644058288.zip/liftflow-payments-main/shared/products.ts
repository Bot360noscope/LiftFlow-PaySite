/**
 * LiftFlow Payments - Fixed Tier Pricing Structure
 * Annual-only billing with volume discounts
 */

export type PricingTier = "free" | "tier_5" | "tier_10" | "tier_25" | "enterprise";

export interface PricingPlan {
  id: PricingTier;
  name: string;
  description: string;
  userCount: number;
  annualPrice: number;
  pricePerUser: number; // For display purposes
  stripePriceId: string;
  features: string[];
  popular?: boolean;
}

// Stripe Price IDs
export const STRIPE_PRICE_IDS = {
  tier_5: "price_1T0gVSE4Zd9PkPJCeBffopZU",
  tier_10: "price_1T0gVTE4Zd9PkPJCR82uwxVo",
  tier_25: "price_1T0gVVE4Zd9PkPJCA7IEwJNZ",
  enterprise: "price_1T0gVWE4Zd9PkPJChjfFNEA3",
};

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "free",
    name: "Free",
    description: "Perfect for getting started",
    userCount: 1,
    annualPrice: 0,
    pricePerUser: 0,
    stripePriceId: "",
    features: [
      "1 client included",
      "Basic workout tracking",
      "Progress monitoring",
      "Mobile app access",
    ],
  },
  {
    id: "tier_5",
    name: "Starter",
    description: "For small coaching practices",
    userCount: 5,
    annualPrice: 100,
    pricePerUser: 20,
    stripePriceId: STRIPE_PRICE_IDS.tier_5,
    features: [
      "5 clients included",
      "Everything in Free",
      "Unlimited workout programs",
      "Advanced analytics",
      "Email support",
    ],
    popular: true,
  },
  {
    id: "tier_10",
    name: "Growth",
    description: "Scale your coaching business",
    userCount: 10,
    annualPrice: 175,
    pricePerUser: 17.5,
    stripePriceId: STRIPE_PRICE_IDS.tier_10,
    features: [
      "10 clients included",
      "Everything in Starter",
      "Priority support",
      "Custom branding",
      "Save 12.5% per user",
    ],
  },
  {
    id: "tier_25",
    name: "Professional",
    description: "For established coaches",
    userCount: 25,
    annualPrice: 375,
    pricePerUser: 15,
    stripePriceId: STRIPE_PRICE_IDS.tier_25,
    features: [
      "25 clients included",
      "Everything in Growth",
      "Dedicated account manager",
      "API access",
      "Save 25% per user",
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    description: "For growing teams",
    userCount: 999, // Unlimited
    annualPrice: 500,
    pricePerUser: 0,
    stripePriceId: STRIPE_PRICE_IDS.enterprise,
    features: [
      "Unlimited users (25+)",
      "Everything in Professional",
      "Custom integrations",
      "SLA guarantee",
      "White-label options",
    ],
  },
];

/**
 * Get pricing plan by tier ID
 */
export function getPricingPlan(tier: PricingTier): PricingPlan | undefined {
  return PRICING_PLANS.find((plan) => plan.id === tier);
}

/**
 * Calculate savings compared to base price
 */
export function calculateSavings(tier: PricingTier): number {
  const plan = getPricingPlan(tier);
  if (!plan || tier === "free" || tier === "enterprise") return 0;
  
  const basePricePerUser = 20; // $20/user for 5-user tier
  const actualPricePerUser = plan.pricePerUser;
  const savingsPerUser = basePricePerUser - actualPricePerUser;
  const percentSavings = (savingsPerUser / basePricePerUser) * 100;
  
  return Math.round(percentSavings);
}
