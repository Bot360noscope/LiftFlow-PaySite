# LiftFlow Payments Integration Guide

This document explains how to integrate the LiftFlow Payments site with the main LiftFlow application.

## Overview

The LiftFlow Payments site is a standalone billing website that handles Stripe checkout for LiftFlow premium subscriptions. It processes payments and notifies the main LiftFlow app via webhook to upgrade user accounts.

## Pricing Structure

- **Free Tier**: 1 client included (no payment required)
- **Pay-per-user**: $5/month or $50/year per additional user (first user free)
- **Enterprise**: $1,000/year for unlimited users (25+ users)

## Integration Flow

1. User clicks "Upgrade" in LiftFlow app
2. LiftFlow redirects to payment site with user info in URL
3. User selects plan and completes Stripe checkout
4. Stripe sends webhook to payment site
5. Payment site calls LiftFlow webhook to upgrade account
6. User is redirected back to LiftFlow with success message

## URL Parameters

When redirecting users from LiftFlow to the payment site, include these parameters:

```
https://your-payment-site.manus.space/pricing?userId=123&email=coach@example.com
```

**Parameters:**
- `userId` (optional): User's ID in LiftFlow database
- `email` (required): User's email address

## LiftFlow Webhook Configuration

The payment site will call your LiftFlow webhook after successful payment. You need to configure these environment variables in the payment site:

### 1. Update `LIFTFLOW_WEBHOOK_URL`

Set this to your actual LiftFlow domain after publishing:

```
https://YOUR-LIFTFLOW-DOMAIN.manus.space/api/trpc/billing.upgradeToPremium
```

**How to update:**
1. Go to payment site Management UI → Settings → Secrets
2. Find `LIFTFLOW_WEBHOOK_URL`
3. Update with your actual LiftFlow domain

### 2. Verify `LIFTFLOW_WEBHOOK_SECRET`

This is already set to:
```
8e9b275bc4259e8155acec58f766d6c5b7f1e8918fef7b783cff51aa314f8cca
```

Make sure your LiftFlow backend uses this same secret to verify webhook calls.

## Webhook Payload

The payment site will POST this JSON to your LiftFlow webhook:

```json
{
  "email": "coach@example.com",
  "tier": "per_user",
  "billingCycle": "monthly",
  "userCount": 5,
  "timestamp": "2026-02-12T19:00:00.000Z"
}
```

**Headers:**
```
Content-Type: application/json
X-Webhook-Secret: 8e9b275bc4259e8155acec58f766d6c5b7f1e8918fef7b783cff51aa314f8cca
```

## LiftFlow Backend Implementation

In your LiftFlow backend, create the webhook endpoint:

```typescript
// server/routers/billing.ts
export const billingRouter = router({
  upgradeToPremium: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        tier: z.enum(["per_user", "enterprise"]),
        billingCycle: z.enum(["monthly", "annual"]),
        userCount: z.number().optional(),
        timestamp: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Verify webhook secret from header
      const secret = ctx.req.headers["x-webhook-secret"];
      if (secret !== process.env.LIFTFLOW_WEBHOOK_SECRET) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid webhook secret",
        });
      }

      // Find user by email
      const user = await getUserByEmail(input.email);
      if (!user) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "User not found",
        });
      }

      // Update user's plan in database
      await updateUserPlan(user.id, {
        plan: input.tier,
        billingCycle: input.billingCycle,
        userLimit: input.tier === "enterprise" ? null : input.userCount,
        planActivatedAt: new Date(),
      });

      return { success: true };
    }),
});
```

## Stripe Configuration

### Test Mode (Development)

1. Go to https://dashboard.stripe.com/test/apikeys
2. Copy your test keys and add them to payment site:
   - Settings → Payment → Stripe Keys
3. Use test card: `4242 4242 4242 4242`

### Live Mode (Production)

1. Complete Stripe KYC verification
2. Go to https://dashboard.stripe.com/apikeys
3. Copy your live keys and update in Settings → Payment
4. Configure webhook endpoint in Stripe Dashboard:
   - URL: `https://your-payment-site.manus.space/api/stripe/webhook`
   - Events: `checkout.session.completed`, `payment_intent.succeeded`, `payment_intent.payment_failed`

## Redirect URLs

After payment, users are redirected back to LiftFlow. Update these URLs in the payment site code:

**Files to update:**
- `client/src/pages/Success.tsx` (line 18 and 89)
- `client/src/pages/Error.tsx` (line 71)

Replace `https://YOUR-LIFTFLOW-DOMAIN.manus.space` with your actual LiftFlow domain.

## Database Schema

The payment site tracks:

- **payments**: All payment transactions with Stripe session IDs
- **subscriptions**: Active subscriptions with tier and billing info

You can view this data in Management UI → Database.

## Testing Checklist

- [ ] Update `LIFTFLOW_WEBHOOK_URL` with actual LiftFlow domain
- [ ] Implement webhook endpoint in LiftFlow backend
- [ ] Test payment flow with Stripe test card
- [ ] Verify webhook is called after successful payment
- [ ] Verify user plan is upgraded in LiftFlow database
- [ ] Test redirect back to LiftFlow after payment
- [ ] Update redirect URLs in Success/Error pages
- [ ] Test with live Stripe keys before production

## Support

For issues or questions:
- Check Stripe Dashboard → Developers → Webhooks for delivery logs
- Check payment site Database for payment records
- Check `.manus-logs/devserver.log` for webhook errors

## Security Notes

- Never expose `STRIPE_SECRET_KEY` or `LIFTFLOW_WEBHOOK_SECRET`
- Always verify webhook signatures from Stripe
- Always verify `X-Webhook-Secret` header in LiftFlow webhook
- Use HTTPS for all production URLs
